-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-09-2024 a las 14:46:58
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `comentariosdb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comentario` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id`, `nombre`, `email`, `comentario`, `fecha`) VALUES
(1, 'Osquo Balderrama', 'ossss589@gmail.com', 'Me gusto la pagina', '2024-09-20 00:28:39'),
(2, 'milagros balderrama', 'agmbr2@gmail.com', 'Me gusta esta pagina web ', '2024-09-20 00:29:46'),
(3, 'Milagros Urssino ', 'milagros.urssino@comunidad.ub.edu.ar', 'Podria mejorar', '2024-09-20 00:31:16'),
(4, 'Megan Harrison ', 'megan.harrison@comunidad.ub.edu.ar', 'Sugerencia. Agreguen mas cosas', '2024-09-20 00:37:21'),
(5, 'Benjamin Azcona ', 'benjamin.azcona@comunidads.ub.edu.ar', 'Buena pagina', '2024-09-20 01:06:52'),
(6, 'Palomo Puerta', 'paloma.puerta@comunidad.ub.edu.ar', '¿Que mas ofrece?', '2024-09-20 01:11:46'),
(7, 'Ingrid Momberg', 'Ingmomb80@gmail.com', 'Me encanta', '2024-09-20 01:21:54'),
(8, 'Mirando Polito Melul', 'miranda.polito@comunidad.ub.edu.ar', 'Mejorala pagina ', '2024-09-20 15:34:40'),
(9, 'Felipe ', 'felipe.paredes@comunidad.ub.edu.ar', 'Genial', '2024-09-20 16:03:02'),
(10, 'Anna Octtaviano', 'anna.octtaviano@comunidad.ub.edu.ar', 'Agrega mas animaciones', '2024-09-20 20:47:56'),
(11, 'Patricia ', 'patricia.daiter@gmai.com', 'Mejore secciones', '2024-09-23 12:26:47');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
